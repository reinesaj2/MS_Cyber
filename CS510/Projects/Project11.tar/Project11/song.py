# song.py - a class that represents a song
# Author:

class Song:
    """A song.

    attributes: rank, artist, title, len, year
    """

    #def __init__():
        """
        rank: int
        artist: String
        title: String
        len: Time
        year: int
        """


    #def __str__():
        """Returns a string representation of the song that includes:
        1. its title
        2. its year
        3. its artist
        """
