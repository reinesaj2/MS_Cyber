# main.py - create two playlists and allow the user to interact with them.
# Author:

#def import_data():

# Read each line from the text file and instantiate a new Song
# Add the song to the big playlist.
# With a 2% chance, also add the song to the small playlist.
# This should result in about 10 of the 500 songs being on the small playlist.
# Hint: use the random.randint(1, 50) function to choose a random integer
# between 1 and 50 - there is a 2% chance of it being any particular number.


def print_menu():
    print('1. Display small playlist info')
    print('2. Add a song to the small playlist')
    print('3. Delete a song from the small playlist')
    print('4. Sort small playlist')
    print('5. Search big playlist by artist')
    print('6. Exit')


def get_choice():
    ch = ''
    while not ch.isdigit() or int(ch) < 1 or int(ch) > 6:
        ch = input('Choice: ')
    return int(ch)


def sort_menu():
    print('Sort by:')
    print('1. Rank')
    print('2. Title')
    print('3. Artist')
    print('4. Length')
    print('5. Year')


if __name__ == '__main__':
    big_playlist = playlist.Playlist("Big Playlist")
    small_playlist = playlist.Playlist("Small Playlist")
    import_data(big_playlist, small_playlist)
    import_data(big_playlist, small_playlist)
    choice = 0
    while choice != 6:
        print_menu()
        choice = get_choice()
        if choice == 1:
            print(small_playlist)
            small_playlist.print_songs()
        elif choice == 2:
            add_song(small_playlist)
        elif choice == 3:
            del_song(small_playlist)
        elif choice == 4:
            do_sort(small_playlist)
        elif choice == 5:
            search_artist(big_playlist)
