# playlist.py - a class that represents a playlist of songs
# Author:

class Playlist:
    """A playlist has a name and contains zero or more songs."""

    #def __init__):
        """Initialize the playlist by setting its name and the list of songs
	to empty.
	Hint: see the BadKangaroo example at the end of Chapter 17 and make sure
	you don't make the same mistake in your playlist code.
	"""

    #def __str__():
        """Return a string representation of the playlist that includes:
        1. its name
        2. the number of songs it contains
        3. the total duration
        """


    #def add_song():
        """Adds the given song to the playlist"""


    #def del_song():
        """Deletes the given song from the playlist"""


    #def search():
	"""Print all songs on the playlist by the given artist"""


    #def sort():
	"""Sort the songs on the playlist based on a given field
	You can use the built-in list function sort to sort on a given field:
	list.sort(key=lambda song: song.rank)
	Note: the less than operator must be defined to use the built-in sort function
	Less than is already defined for ints and strings, but you will have to
	overload the less than operator so that it works on your Time class.
	"""

    #def print_songs():
        """Prints all the songs on a playlist."""


    #def duration():
        """Calculates the duration of a playlist by adding the length of all its songs."""

